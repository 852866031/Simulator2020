package Simulator;

// Author: Isidora Duma
public enum Movement {
    UP,
    DOWN,
    FORWARD,
    LEFT,
    RIGHT,
    UPRIGHT,
    UPLEFT,
    DOWNRIGHT,
    DOWNLEFT
}
