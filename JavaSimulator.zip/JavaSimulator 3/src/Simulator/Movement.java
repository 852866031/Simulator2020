package Simulator;

public enum Movement {
    UP,
    DOWN,
    FORWARD,
    LEFT,
    RIGHT,
    UPRIGHT,
    UPLEFT,
    DOWNRIGHT,
    DOWNLEFT
}
