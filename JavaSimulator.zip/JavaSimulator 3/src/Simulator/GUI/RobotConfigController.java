package Simulator.GUI;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class RobotConfigController {
    private int width;
    private int height;
    private String name;
    private int x = -1;
    private int y = -1;
    private double magnitude;
    private double angle;
    private double time;

    public RobotConfigController(int width, int height) {
        this.width = width;
        this.height = height;
    }

    @FXML
    private Label gridLabel;

    @FXML
    private TextField xPos;

    @FXML
    private TextField yPos;

    @FXML
    private TextField robotName;

    @FXML
    public void initialize() {
        gridLabel.setText(width + " x " + height);
    }

    @FXML
    public void submit(MouseEvent event) {

        if(xPos.getText().isEmpty() || !xPos.getText().matches("^\\d+$")
                || yPos.getText().isEmpty() || !yPos.getText().matches("^\\d+$")) {
            System.out.println("Position input must be a positive integer.");
        }
        else if(Integer.parseInt(xPos.getText()) > (width - 1)) {
            System.out.println("Must be within bounds");
        }
        else if(Integer.parseInt(yPos.getText()) > (height - 1)) {
            System.out.println("Must be within bounds");
        }
        else {
            x = Integer.parseInt(xPos.getText());
            y = Integer.parseInt(yPos.getText());

            name = robotName.getText();

            System.out.println("x: " + x);
            System.out.println("y: " + y);
            System.out.println("name: " + name);

            Stage stage = (Stage) gridLabel.getScene().getWindow();
            stage.close();
        }
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public double getMagnitude() {
        return magnitude;
    }

    public void setMagnitude(double magnitude) {
        this.magnitude = magnitude;
    }

    public double getAngle() {
        return angle;
    }

    public void setAngle(double angle) {
        this.angle = angle;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }
}
