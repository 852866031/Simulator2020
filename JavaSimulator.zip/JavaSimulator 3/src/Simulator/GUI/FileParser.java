package Simulator.GUI;

import Simulator.GUI.Tile;
import Simulator.Movement;
import Simulator.avatar;
import javafx.scene.image.Image;

public class FileParser {

    private int width;
    private int height;
    private Tile[][] grid;
    private double wind;
    private double windDir;
    private double temp;
    private boolean outside;

    public String saveMapInside(int width, int height, double temp, Tile[][] grid) {
        StringBuilder sb = new StringBuilder();

        sb.append("in\n");
        sb.append("[width],[height]\n");
        sb.append(width + "," + height + "\n");
        sb.append("[temp]\n");
        sb.append(temp + "\n");
        sb.append("[x],[y],[height],[object]\n");

        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                Tile c = grid[i][j];
                sb.append(i + " " + j + "," + c.getCellHeight() + ",");
                if(c.isBox()) {
                    sb.append("box," + c.getBoxMass() + "\n");
                }
                else if(c.isWall()) {
                    sb.append("wall\n");
                }
                else {
                    sb.append("N\n");
                }
            }
        }

        return sb.toString();
    }

    // currently only handles 1 robot
    public String saveRobot(int width, int height, String name, int x, int y) {
        StringBuilder sb = new StringBuilder();

        sb.append("[width],[height]\n");
        sb.append(width + "," + height + "\n");
        sb.append("[name of robot],[x],[y]\n");
        sb.append(name + "," + x + "," + y + "\n");
        return sb.toString();
    }

    public String saveMapOutside(int width, int height, double wind, double windDir, double temp, Tile[][] grid) {
        StringBuilder sb = new StringBuilder();

        sb.append("out\n");
        sb.append("[width],[height]\n");
        sb.append(width + "," + height + "\n");
        sb.append("[wind speed],[wind direction],[temp]\n");
        sb.append(wind + "," + windDir + "," + temp + "\n");
        sb.append("[x],[y],[height],[terrain],[object],[mass]\n");

        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                Tile c = grid[i][j];
                sb.append(i + " " + j + "," + c.getCellHeight() + ",");

                if(c.isWater()) {
                    sb.append("water");
                }
                else if(c.isGrass()) {
                    sb.append("grass");
                }
                else if(c.isSand()) {
                    sb.append("sand");
                }
                else {
                    sb.append("concrete");
                }

                if(c.isBox()) {
                    sb.append(",box," + c.getBoxMass() + "\n");
                }
                else if(c.isWall()) {
                    sb.append(",wall\n");
                }
                else if(c.isTree()) {
                    sb.append(",tree\n");
                }
                else {
                    sb.append(",N\n");
                }
            }
        }
        return sb.toString();
    }

    public String buildOutput(int[] avatarDir, avatar player, int[] oldPos, double startTime, Tile avatar) {

        String command;

        if(avatarDir[0]==0 && avatarDir[1]==1) {    // right

            if(oldPos[1] == player.y && oldPos[0] == player.x) {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.RIGHT + ",TURN\n";
            }
            else {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.RIGHT + ",MOVE\n";
            }

        } else if(avatarDir[0]==0 && avatarDir[1]==-1) {    //left

            if(oldPos[1] == player.y && oldPos[0] == player.x) {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.LEFT + ",TURN\n";
            }
            else {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.LEFT + ",MOVE\n";
            }

        } else if(avatarDir[0]==1 && avatarDir[1]==0) {     // down

            if(oldPos[1] == player.y && oldPos[0] == player.x) {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.DOWN + ",TURN\n";
            }
            else {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.DOWN + ",MOVE\n";
            }

        }else if(avatarDir[0]==-1 && avatarDir[1]==0){     // up

            if(oldPos[1] == player.y && oldPos[0] == player.x) {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.UP + ",TURN\n";
            }
            else {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.UP + ",MOVE\n";
            }

        }else if(avatarDir[0]==-1 && avatarDir[1]==-1){     // up left

            if(oldPos[1] == player.y && oldPos[0] == player.x) {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.UPLEFT + ",TURN\n";
            }
            else {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.UPLEFT + ",MOVE\n";
            }

        }else if(avatarDir[0]==-1 && avatarDir[1]==1){     // up right

            if(oldPos[1] == player.y && oldPos[0] == player.x) {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.UPRIGHT + ",TURN\n";
            }
            else {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.UPRIGHT + ",MOVE\n";
            }

        }else if(avatarDir[0]==1 && avatarDir[1]==-1) {     // down left

            if(oldPos[1] == player.y && oldPos[0] == player.x) {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.DOWNLEFT + ",TURN\n";
            }
            else {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.DOWNLEFT + ",MOVE\n";
            }

        }else {     // down right

            if(oldPos[1] == player.y && oldPos[0] == player.x) {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.DOWNRIGHT + ",TURN\n";
            }
            else {
                command = "robot," + player.y + "," + player.x + "," + (System.currentTimeMillis() - startTime) + "," + avatar.getCellHeight() + "," + Movement.DOWNRIGHT + ",MOVE\n";
            }
        }
        return command;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public Tile[][] getGrid() {
        return grid;
    }

    public void setGrid(Tile[][] grid) {
        this.grid = grid;
    }

    public double getWind() {
        return wind;
    }

    public void setWind(double wind) {
        this.wind = wind;
    }

    public double getWindDir() {
        return windDir;
    }

    public void setWindDir(double windDir) {
        this.windDir = windDir;
    }

    public double getTemp() {
        return temp;
    }

    public void setTemp(double temp) {
        this.temp = temp;
    }
}
