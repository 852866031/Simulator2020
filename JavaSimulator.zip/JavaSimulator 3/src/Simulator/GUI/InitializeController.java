package Simulator.GUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

public class InitializeController {

    private File file;

    @FXML
    private TextField simWidth;

    @FXML
    private TextField simHeight;

    @FXML
    private Button fileBtn;

    @FXML
    private CheckBox inside;

    @FXML
    private CheckBox outside;

    @FXML
    public void initialize(){
        inside.setSelected(true);
    }

    public void loadFile(ActionEvent event) {

        FileChooser fc = new FileChooser();
        fc.setTitle("Open Old Map File");
        File f = fc.showOpenDialog((Stage) simHeight.getScene().getWindow());

        if (f != null) {
            if (!f.getName().endsWith(".csv")) {
                System.out.println("file must be csv");
            } else {
                fileBtn.setText(f.getName());
            file = f;
            }
        }
    }

    public void enterSubmit(ActionEvent event) throws IOException {

        // file chosen
        if(file != null) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../resources/Sim.fxml"));
            loader.setController(new SimController(file));
            Parent map = loader.load();
            Stage simStage = new Stage();

            simStage.setTitle("Simulator");
            simStage.setScene(new Scene(map, 866, 629));
            simStage.show();
        }

        // check grid size valid
        else if(simWidth.getText() != null && !simWidth.getText().isEmpty() && simHeight.getText() != null && !simHeight.getText().isEmpty()){
            if(simWidth.getText().matches("\\d*") && simWidth.getText().matches("\\d*")){
                if(Integer.parseInt(simWidth.getText()) >= 10 && Integer.parseInt(simHeight.getText()) >= 10){

                    FXMLLoader loader = new FXMLLoader(getClass().getResource("../resources/Sim.fxml"));
                    loader.setController(new SimController(Integer.parseInt(simWidth.getText()), Integer.parseInt(simHeight.getText()), outside.isSelected()));
                    Parent map = loader.load();
                    Stage simStage = new Stage();

                    simStage.setTitle("Simulator");
                    simStage.setScene(new Scene(map, 869, 629));
                    simStage.show();

                }
            }
        }
        else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../resources/Sim.fxml"));
            loader.setController(new SimController(10, 10, outside.isSelected()));
            Parent map = loader.load();
            Stage simStage = new Stage();

            simStage.setTitle("Simulator");
            simStage.setScene(new Scene(map, 869, 629));
            simStage.show();
        }

        Stage stage = (Stage) fileBtn.getScene().getWindow();
        stage.close();
    }


    public void insideSelected(ActionEvent event) {
        if(inside.isSelected()){
            outside.setSelected(false);
        }

    }

    public void outsideSelected(ActionEvent event) {
        if(outside.isSelected()) {
            inside.setSelected(false);
        }
    }
}
