package Simulator.GUI;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class CreateCellInsideController {
    private int x;
    private int y;
    private int friction;
    private int height;
    private boolean box;
    private boolean wall;

    private Double boxMass;

    public CreateCellInsideController(){}

    public CreateCellInsideController(int x, int y){
        this.x = x;
        this.y = y;
     }

    @FXML
    private Label cellIndex;

    @FXML
    private TextField cellHeight;

    @FXML
    private CheckBox wallCheck;

    @FXML
    private CheckBox boxCheck;

    @FXML
    private Button submitBtn;

    @FXML
    private TextField mass;

    @FXML
    private Label massLabel;

    @FXML
    private Label kgLabel;

    @FXML
    public void initialize(){
        cellIndex.setText("Cell: (" + x + ", " + y + ")");
        setFriction(0);
        setHeight(0);

        mass.setVisible(false);
        massLabel.setVisible(false);
        kgLabel.setVisible(false);
    }

    @FXML
    public void submit(MouseEvent event){

        int h;
        int f;
        boolean hasOb;
        box = false;
        wall = false;

        // set height attributes
        // 0 if empty
        // do not continue if not numerical
        if(cellHeight.getText().isEmpty() || cellHeight.getText() == null){
            h = 0;
        }
        else if(!cellHeight.getText().matches("^(?:[1-9]\\d*|0)?(?:\\.\\d+)?$")){
            return;
        }
        else {
            h = Integer.parseInt(cellHeight.getText());
        }
        if(wallCheck.isSelected()){
            wall = true;
        }
        else if(boxCheck.isSelected()){
            box = true;
        }

        if(box){
            if(!mass.getText().isEmpty() && mass.getText().matches("^(?:[1-9]\\d*|0)?(?:\\.\\d+)?$")){
                boxMass = Double.parseDouble(mass.getText());
            }
            else {
                boxMass = 2.0;
            }
        }

        setHeight(h);

        Stage stage = (Stage) submitBtn.getScene().getWindow();
        stage.close();
    }

    public void wallSelected(ActionEvent event) {
        if(wallCheck.isSelected()){
            boxCheck.setSelected(false);
            mass.setVisible(false);
            massLabel.setVisible(false);
            kgLabel.setVisible(false);
        }
    }

    public void boxSelected(ActionEvent event) {
        if(boxCheck.isSelected()) {
            wallCheck.setSelected(false);
            mass.setVisible(true);
            mass.setText("2.0");
            massLabel.setVisible(true);
            kgLabel.setVisible(true);
        }
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getFriction() {
        return friction;
    }

    public void setFriction(int friction) {
        this.friction = friction;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public boolean isBox() {
        return box;
    }

    public void setBox(boolean box) {
        this.box = box;
    }

    public boolean isWall() {
        return wall;
    }

    public void setWall(boolean wall) {
        this.wall = wall;
    }

    public Double getBoxMass() {
        return boxMass;
    }

    public void setBoxMass(Double boxMass) {
        this.boxMass = boxMass;
    }
}