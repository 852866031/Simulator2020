package Simulator.GUI;

import Simulator.*;
import Simulator.api.AISimAPI;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.input.KeyEvent;
import javafx.util.Duration;

import javax.swing.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class SimController {

    private int width;
    private int height;
    private Tile[][] grid;
    private File file;
    private double wind;
    private double temp;
    private char windDir;
    public world world;
    private StringBuilder output;
    private boolean started;
    private long startTime;
    private String command;
    XYChart.Series series;
    private boolean outside;
    private RobotConfigController rcController;
    private avatar player;
    private boolean robotSetup;
    private double magnitude;
    private double angle;
    private double time;
    private SimController sc;
    private AISimAPI ai;
    Timeline timeline;

    public SimController() {
    }

    public SimController(int width, int height, boolean outside){
        this.width = width;
        this.height = height;

        grid = new Tile[width][height];

        output = new StringBuilder();

        output.append("[name],[x],[y],[time],[height],[direction],[action]\n");

        this.outside = outside;

        this.robotSetup = false;
        this.sc=this;

        ai = new AISimAPI();
    }

    public SimController(File file){
        this.file = file;
        output = new StringBuilder();
        output.append("[name],[x],[y],[time],[height],[direction],[action]\n");
        this.robotSetup = false;
    }

    @FXML
    private Pane gridMap;

    @FXML
    private TextField windText;

    @FXML
    private TextField tempText;

    @FXML
    private TextField heightText;

    @FXML
    private TextField directionText;

    @FXML
    private MenuItem saveMapOpt;

    @FXML
    private LineChart elevationChart;

    @FXML
    private CategoryAxis x;

    @FXML
    private NumberAxis y;

    @FXML
    private Button loadConfigBtn;

    @FXML
    private Button robotSetupbtn;

    @FXML
    private Label or;

    @FXML
    public void initialize(){

        if(file == null) {
            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Tile tile = new Tile(i, j, width, height, false, outside);
                    grid[i][j] = tile;
                    gridMap.getChildren().add(tile);
                }
            }
            if(!outside) {
                windText.setEditable(false);
                directionText.setEditable(false);
            }
        }
        else {
            parseFile();
        }
    }

    @FXML
    public void start(MouseEvent event) throws InterruptedException {

        Scene scene = windText.getScene();

        if(!started && robotSetup) {
            started = true;

            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Tile tile = grid[i][j];
                    tile.setLoadedFromFile(true);
                    tile.setOnMouseClicked(e -> {
                    });
                }
            }

            if (windText.getText().isEmpty() || windText.getText() == null || !windText.getText().matches("[0-9]{1,13}(\\.[0-9]*)?")) {
                wind = 0;
            } else {
                wind = Double.parseDouble(windText.getText());
            }

            windText.setText(String.valueOf(wind));
            windText.setEditable(false);

            if (tempText.getText().isEmpty() || tempText.getText() == null || !tempText.getText().matches("[0-9]{1,13}(\\.[0-9]*)?")) {
                temp = 0;
            } else {
                temp = Double.parseDouble(tempText.getText());
            }

            tempText.setText(String.valueOf(temp));
            tempText.setEditable(false);

            if (directionText.getText().isEmpty() || directionText.getText() == null || directionText.getText().length() > 1) {
                windDir = 'N';
            } else {
                windDir = directionText.getText().charAt(0);
            }

            directionText.setText(String.valueOf(windDir));
            directionText.setEditable(false);

            int[][] heights = new int[height][width];
            char[][] terrain = new char[height][width];
            world = new map(height, width, terrain, heights, player);
            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Tile c = grid[i][j];
                    heights[i][j] = c.getCellHeight();

                    // set terrain/friction here
                    if (!c.isOutside()) {
                        // set friction index for inside ground
                        c.setFriction(0.005);
                        ((map) world).cellList.getCellAt(i, j).setFrictionIndex(0.005);
                        terrain[i][j] = 's';
                    } else if (c.isGrass()) {
                        // set friction for grass
                        c.setFriction(0.0095);
                        ((map) world).cellList.getCellAt(i, j).setFrictionIndex(0.0095);
                        terrain[i][j] = 'g';
                    } else if (c.isSand()) {
                        // set friction for sand
                        c.setFriction(0.0029);
                        ((map) world).cellList.getCellAt(i, j).setFrictionIndex(0.029);
                        terrain[i][j] = 's';
                    } else if (c.isWater()) {
                        ((map) world).cellList.getCellAt(j, i).setWater();
                        terrain[i][j] = 'w';
                    } else if (c.isConcrete()) {
                        // set friction for concrete
                        // default
                        c.setFriction(0.0035);
                        ((map) world).cellList.getCellAt(i, j).setFrictionIndex(0.0035);
                        terrain[i][j] = 'c';
                    }

                    if (c.getTileFill() == null && c.isOutside()) {
                        c.setTileFill(Color.GRAY);
                    } else if (c.getTileFill() == null && !c.isOutside()) {
                        c.setTileFill(Color.LIGHTGRAY);
                    }
                }
            }

            player.initialize(((map) world).cellList);

            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Tile c = grid[i][j];
                    if (c.isBox()) {
                        worldObject wo = new worldObject(i, j, "Box", c.getBoxMass(), true, ((map) world).cellList);
                        world.addObject(wo);
                        ((map) world).cellList.getCellAt(j, i).setObject(wo);
                    }
                    if (c.isWall()) {
                        worldObject wo = new worldObject(j, i, "Wall", -1, false, ((map) world).cellList);
                        world.addObject(wo);
                        ((map) world).cellList.getCellAt(j, i).setObject(wo);
                    }
                    if (c.isTree()) {
                        worldObject wo = new worldObject(j, i, "Tree", -1, false, ((map) world).cellList);
                        world.addObject(wo);
                        ((map) world).cellList.getCellAt(j, i).setObject(wo);
                    }
                }
            }

            Tile avatar = grid[player.y][player.x];
            heightText.setText(String.valueOf(avatar.getCellHeight()));

            Image playerImage = new Image(getClass().getResource("../resources/avatar_down.png").toString());
            avatar.border.setFill(new ImagePattern(playerImage));

            startTime = System.currentTimeMillis();

            series = new XYChart.Series();

            series.getData().add(new XYChart.Data("0", avatar.getCellHeight()));
            elevationChart.getData().addAll(series);

            timeline = new Timeline(new KeyFrame(Duration.seconds(2), new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent event) {

                    int[] result;

                    Sensor sensor = new Sensor();
                    result = sensor.simpleDetectDistanceBySonic(player, (map)world, outside);

                    ai.sendNN(result);

                    // { "MOVE","2","LEFT" }
                    // { "MOVE","1","FORWARD" }
                    // ETC...
                    ArrayList<String> input = ai.getCommand();

                    String direction;

                    if(input.get(0).equalsIgnoreCase("MOVE")) {
                        direction = input.get(2);
                    }
                    else {
                        direction = "";
                    }

                    int numMoves = Integer.parseInt(input.get(1));

                    int[] avatarDir = ((map) world).getPlayer().getAvatarDir();
                    int[] oldPos = new int[2];
                    try {
                        DirectionConverter dc = new DirectionConverter();
                        char move;

                        // convert direction to qweasdzc
                        if(avatarDir[0]==0 && avatarDir[1]==1) {    // east
                            move = dc.east(direction);

                        } else if(avatarDir[0]==0 && avatarDir[1]==-1) {    // west
                            move = dc.west(direction);

                        } else if(avatarDir[0]==1 && avatarDir[1]==0) {     // south
                            move = dc.south(direction);

                        }else if(avatarDir[0]==-1 && avatarDir[1]==0){     // north
                            move = dc.north(direction);

                        }else if((avatarDir[0]==-1 && avatarDir[1]==-1)){     // north west
                            move = dc.northWest(direction);
                        }
                        else if(avatarDir[0]==1 && avatarDir[1]==-1) {  // south west
                            move = dc.southWest(direction);
                        }
                        else if(avatarDir[0]==-1 && avatarDir[1]==1) {     // north east
                            move = dc.northEast(direction);
                        }
                        else {  // south east
                            move = dc.southEast(direction);
                        }

                        for(int i=0; i < numMoves; i++) {
                            oldPos = world.updateSim(player, move);
                            moveAvatarOnScreen(oldPos);
                        }

                        Tile myAv = grid[oldPos[1]][oldPos[0]];
                        series.getData().add(new XYChart.Data(String.valueOf((System.currentTimeMillis() - startTime)/1000.), myAv.getCellHeight()));

                    } catch (IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                }
            }));
            timeline.setCycleCount(Timeline.INDEFINITE);
            timeline.play();
        }
        if(started) {
            timeline.play();
        }
    }

    @FXML
    public void pause(MouseEvent event){
        timeline.pause();
    }

    @FXML
    public void end(MouseEvent event){
        timeline.stop();
        startTime = System.currentTimeMillis();
        System.out.println(output);
    }

    @FXML
    public void robotSetup(MouseEvent event) throws IOException {
        System.out.println(width + "," + height);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../resources/RobotConfig.fxml"));
        loader.setController(rcController = new RobotConfigController(width, height));
        Parent map = loader.load();
        Stage robotConfig = new Stage();

        robotConfig.setTitle("Robot configuration");
        robotConfig.setScene(new Scene(map, 368, 277));
        robotConfig.show();

        robotConfig.setOnHidden(e -> {
            if(rcController.getX() == -1 || rcController.getY() == -1 ) {
                System.out.println("Please set up robot correctly.");
                this.robotSetup = false;
                return;
            }
            this.player=new avatar(new int[]{rcController.getX(), rcController.getY()}, new int[]{1, 0}, 90);

            rcController.getName();

            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Tile c = grid[i][j];
                    c.allowCreate();
                }
            }
            this.robotSetup = true;
        });
    }

    @FXML
    public void robotFileConfig(MouseEvent event) {

        FileChooser fc = new FileChooser();
        fc.setTitle("Load Robot Configuration File");
        File f = fc.showOpenDialog((Stage) windText.getScene().getWindow());

        if (f != null) {
            if (!f.getName().endsWith(".csv")) {
                System.out.println("file must be csv");
            } else {
                Path pathToFile = Paths.get(f.getPath());

                try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {
                    br.readLine(); // [width],[height]

                    String line = br.readLine();
                    String[] wh = line.split(",");

                    if(this.width != Integer.parseInt(wh[0]) || this.height != Integer.parseInt(wh[1])) {
                        System.out.println("Robot configuration file must have matching grid size.");
                    }
                    else {
                        br.readLine();  // [name of robot],[x],[y]
                        line = br.readLine();
                        String[] attributes = line.split(",");

                        this.player=new avatar(new int[]{Integer.parseInt(attributes[1]), Integer.parseInt(attributes[2])}, new int[]{1, 0}, 90);
                        System.out.println(Integer.parseInt(attributes[1]) + "," + Integer.parseInt(attributes[2]));
                        robotSetup = true;
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @FXML
    public void saveRobotFile(ActionEvent event) {
        String robotToSave = "";
        if(rcController == null) {
            System.out.println("Robot already has config file.");
            return;
        }
        else {
            FileParser fp = new FileParser();
            robotToSave = fp.saveRobot(this.width, this.height, rcController.getName(), rcController.getX(), rcController.getY());
        }
        saveFile("Save Robot File", robotToSave);
    }


    public void moveAvatarOnScreen(int[] oldPos) {

        Tile av = grid[player.y][player.x];
        heightText.setText(String.valueOf(av.getCellHeight()));

        int[] avatarDir = ((map) world).getPlayer().getAvatarDir();

        Image playerImage;

        try {
            // append current command to output file
            FileParser fp = new FileParser();
            command = fp.buildOutput(avatarDir, player, oldPos, startTime, av);
            System.out.println(command);
            output.append(command);

            // change the direction of the avatar on screen
            if(avatarDir[0]==0 && avatarDir[1]==1) {    // right

                playerImage = new Image(getClass().getResource("../resources/avatar_right.png").toString());

            } else if(avatarDir[0]==0 && avatarDir[1]==-1) {    //left

                playerImage = new Image(getClass().getResource("../resources/avatar_left.png").toString());

            } else if(avatarDir[0]==1 && avatarDir[1]==0) {     // down

                playerImage = new Image(getClass().getResource("../resources/avatar_down.png").toString());

            }else if(avatarDir[0]==-1 && avatarDir[1]==0){     // up

                playerImage = new Image(getClass().getResource("../resources/avatar_up.png").toString());
            }else if(avatarDir[0]==-1 && avatarDir[1]==-1){     // up left

                playerImage = new Image(getClass().getResource("../resources/avatar_upleft.png").toString());
            }else if(avatarDir[0]==-1 && avatarDir[1]==1){     // up right

                playerImage = new Image(getClass().getResource("../resources/avatar_upright.png").toString());
            }else if(avatarDir[0]==1 && avatarDir[1]==-1) {     // down left

                playerImage = new Image(getClass().getResource("../resources/avatar_downleft.png").toString());

            }else {     // down right
                playerImage = new Image(getClass().getResource("../resources/avatar_downright.png").toString());
            }

            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Tile c = grid[i][j];

                    if(!(i == player.y && j == player.x)){
                        c.border.setFill(c.getTileFill());
                    }
                    else if(i == player.y && j == player.x){
                        av.border.setFill(new ImagePattern(playerImage));
                    }
                }
            }
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }
    public boolean moveObjOnScreen(int[] oldPos, Obj mobj){
        if(mobj instanceof avatar) {
            moveAvatarOnScreen(oldPos);
            return true;
        }
        Tile o = grid[mobj.y][mobj.x];
        //heightText.setText(String.valueOf(o.getCellHeight()));
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                Tile c = grid[i][j];
                if(!(i == mobj.y && j == mobj.x)){
                    c.border.setFill(c.getTileFill());
                }
                else if(i == mobj.y && j == mobj.x){
                    //reset the obj image
                }
            }
        }
        return false;
    }

    @FXML
    public void saveMapFile(ActionEvent event){

        FileParser fp = new FileParser();
        String mapToSave;
        if(outside) {
            mapToSave = fp.saveMapOutside(width, height, wind, windDir, temp, grid);
        }
        else {
            mapToSave = fp.saveMapInside(width, height, temp, grid);
        }
        saveFile("Save Map File", mapToSave);
    }

    @FXML
    public void saveOutputFile(ActionEvent event) {
        saveFile("Save Output File", output.toString());
    }

    private void saveFile(String title, String content) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle(title);
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV", "*.csv"));
        File file = fileChooser.showSaveDialog((Stage) windText.getScene().getWindow());
        if (file != null) {
            try {
                BufferedWriter br = new BufferedWriter(new FileWriter(file.getPath()));

                br.write(content);
                br.close();

            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    // loads all file info into simulator
    private void parseFile(){

        Path pathToFile = Paths.get(file.getPath());

        try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {
            String line = br.readLine();

            if(line.equals("in")) {
                loadInsideMap(br);
            }
            else if(line.equals("out")) {
                loadOutsideMap(br);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadInsideMap(BufferedReader br) {
        try {
            this.outside = false;
            br.readLine();  // [width],[height]
            String line = br.readLine();

            String[] wh = line.split(",");

            this.width = Integer.parseInt(wh[0]);
            this.height = Integer.parseInt(wh[1]);

            grid = new Tile[width][height];

            br.readLine();  // [temp]

            line = br.readLine();

            this.temp = Double.parseDouble(line);

            br.readLine();  // [x],[y],[height],[object]

            line = br.readLine();
            while(line != null){
                String[] attributes = line.split(",");
                boolean box = false;
                if(attributes.length < 3) {
                    throw new Exception("Malformed file inputted");
                }
                else if(attributes.length == 4) {
                    box = true;
                }

                String cellIndex = attributes[0];
                String cellHeight = attributes[1];
                String object = attributes[2];

                String[] indexes = cellIndex.split(" ");

                int i = Integer.parseInt(indexes[0]);
                int j = Integer.parseInt(indexes[1]);

                System.out.println("loading cell: " + i + "," + j);

                Tile tile = new Tile(i, j, width, height, true, outside);

                tile.setCellHeight(Integer.parseInt(cellHeight));

                if(object.equalsIgnoreCase("wall")){
                    tile.setWall(true);
                    Image playerImage = new Image(getClass().getResource("../resources/metal-box.png").toString());
                    tile.border.setFill(new ImagePattern(playerImage));
                    tile.setTileFill(new ImagePattern(playerImage));
                }
                else if(object.equalsIgnoreCase("box") && box){
                    tile.setBox(true);
                    //tile.setObstacle(false);
                    Image playerImage = new Image(getClass().getResource("../resources/box-zebrawood.png").toString());
                    tile.border.setFill(new ImagePattern(playerImage));
                    tile.setTileFill(new ImagePattern(playerImage));
                    String boxMass = attributes[3];
                    tile.setBoxMass(Double.parseDouble(boxMass));
                }
                grid[i][j] = tile;
                gridMap.getChildren().add(tile);

                line = br.readLine();
            }

            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    if(grid[i][j] == null) {
                        Tile tile = new Tile(i, j, width, height, true, outside);
                        grid[i][j] = tile;
                        gridMap.getChildren().add(tile);
                    }
                }
            }
            windText.setText("0.0");
            tempText.setText(String.valueOf(temp));
            directionText.setText("N");

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadOutsideMap(BufferedReader br) {
        try {
            this.outside = true;
            br.readLine();  // [width],[height]
            String line = br.readLine();

            String[] wh = line.split(",");

            this.width = Integer.parseInt(wh[0]);
            this.height = Integer.parseInt(wh[1]);

            grid = new Tile[width][height];

            br.readLine();  // [wind speed],[wind direction],[temp]

            line = br.readLine();

            wh = line.split(",");

            this.wind = Double.parseDouble(wh[0]);
            this.windDir = wh[1].charAt(0);
            this.temp = Double.parseDouble(wh[2]);

            br.readLine();  // [x],[y],[height],[terrain],[object],[mass]

            line = br.readLine();
            while(line != null){
                String[] attributes = line.split(",");
                boolean box = false;
                if(attributes.length < 4) {
                    throw new Exception("Malformed file inputted");
                }
                else if(attributes.length == 5) {
                    box = true;
                }

                String cellIndex = attributes[0];
                String cellHeight = attributes[1];
                String terrain = attributes[2];
                String object = attributes[3];

                String[] indexes = cellIndex.split(" ");

                int i = Integer.parseInt(indexes[0]);
                int j = Integer.parseInt(indexes[1]);

                System.out.println("loading cell: " + i + "," + j);

                Tile tile = new Tile(i, j, width, height, true, outside);

                tile.setCellHeight(Integer.parseInt(cellHeight));

                if(terrain.equals("water")) {
                    tile.setWater(true);
                    ((map)world).cellList.getCellAt(j ,i).setWater();
                    tile.border.setFill(Color.BLUE);
                    tile.setTileFill(Color.BLUE);
                }
                else if(terrain.equals("grass")) {
                    tile.setGrass(true);

                    tile.border.setFill(Color.GREEN);
                    tile.setTileFill(Color.GREEN);
                }
                else if(terrain.equals("sand")) {
                    tile.setSand(true);

                    tile.border.setFill(Color.BURLYWOOD);
                    tile.setTileFill(Color.BURLYWOOD);
                }
                else {
                    tile.setConcrete(true);

                    tile.border.setFill(Color.GRAY);
                    tile.setTileFill(Color.GRAY);
                }

                if(object.equalsIgnoreCase("wall")){
                    tile.setWall(true);
                    Image playerImage = new Image(getClass().getResource("../resources/metal-box.png").toString());
                    tile.border.setFill(new ImagePattern(playerImage));
                    tile.setTileFill(new ImagePattern(playerImage));
                }
                else if(object.equalsIgnoreCase("box") && box){
                    tile.setBox(true);
                    //tile.setObstacle(false);
                    Image playerImage = new Image(getClass().getResource("../resources/box-zebrawood.png").toString());
                    tile.border.setFill(new ImagePattern(playerImage));
                    tile.setTileFill(new ImagePattern(playerImage));

                    String boxMass = attributes[4];
                    tile.setBoxMass(Double.parseDouble(boxMass));
                }
                grid[i][j] = tile;
                gridMap.getChildren().add(tile);

                line = br.readLine();
            }

            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    if(grid[i][j] == null) {
                        Tile tile = new Tile(i, j, width, height, true, outside);
                        grid[i][j] = tile;
                        gridMap.getChildren().add(tile);
                    }
                }
            }

            windText.setText(String.valueOf(wind));
            tempText.setText(String.valueOf(temp));
            directionText.setText(String.valueOf(windDir));

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
