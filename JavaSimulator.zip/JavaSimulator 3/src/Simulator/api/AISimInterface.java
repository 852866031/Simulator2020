package Simulator.api;

import java.util.ArrayList;

public interface AISimInterface {

    public void sendNN(int input[]);
    public ArrayList<String> getCommand();

}