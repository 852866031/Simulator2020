package Simulator.api;

import java.util.ArrayList;

public class AISimAPI implements AISimInterface {

    public void sendNN(int input[]){

        // send input[] to neural network
    }

    public ArrayList<String> getCommand(){

        // get command from META
        // turn it into arraylist that returns { "MOVE", "2", "FORWARD" }
        // this example means move forward 2 spots
        // directions covered in simulator: see Movement.enum
        // the simulator will convert this direction into a movement

        ArrayList<String> command = new ArrayList<String>();

        // example
        command.add("MOVE");
        command.add("2");
        command.add("FORWARD");

        return command;
    }
}
