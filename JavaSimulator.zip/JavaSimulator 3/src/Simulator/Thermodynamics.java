package Simulator;

public class Thermodynamics {
    private map world;

}
